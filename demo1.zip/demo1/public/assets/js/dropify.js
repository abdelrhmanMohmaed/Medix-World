$(function() {
  'use strict';

  $('#myDropify').dropify();
});